plugins { id("com.android.application") }

android {
    namespace = "cl.erretrez.calculadora3d"
    compileSdk = 35

    defaultConfig {
        applicationId = "cl.erretrez.calculadora3d"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
